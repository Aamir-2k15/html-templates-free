<!DOCTYPE html>
<html lang="en">
    <?php include 'inc/head.php'; ?>
    <body>
        <div class="wrapper">
            <?php include 'inc/sidebar.php'; ?>
            <div class="main-panel">
                <?php include 'inc/header.php'; ?>
                
                <?php include 'inc/footer.php'; ?>
            </div>
        </div>
    </body>
    <?php include 'inc/scripts.php';?>

</html>
